0x01. C - Variables, if, else, while
