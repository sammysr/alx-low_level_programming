#include "main.h"

/**
 * _strlen - Entry point
 * Desc: Entry
 *@s: pointer
 * Return: Always 0 (Success)
 */
int _strlen(char *s)
{
	int i;

	for (i = 0 ; s[i] != '\0'; i++)
	{

	}
	return (i);
}
