#include "main.h"
/**
 * _atoi - convert string to numbers
 *
 * Return: n
 */
int _atoi(void)
{
	/* int x; */
	/* char arr[]; */

	/* while (*s) */
	/* { */
	/* x++; */
	/* if (*s >= 48 && *s <= '9') */
	/* conv[i] = *s */
	/* } */

	return (0);
}
