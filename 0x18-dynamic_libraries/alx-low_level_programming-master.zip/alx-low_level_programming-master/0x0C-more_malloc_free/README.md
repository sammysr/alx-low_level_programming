0-malloc_checked.c
