#include "main.h"
#include <stdio.h>

/**
 * mul - check the code for Holberton School students.
 *@a : variable
 *@b : variable
 * Return: 0 or 1 .
 */
int mul(int a, int b)
{
int result;
result = a * b;
return (result);
}
