#include <stdio.h>
#include "4-sum.h"
#include "4-sum.h"

/**
   * main - check the code for Holberton School students.
    *
     * Return: Always 0.
      */
int main(void)
{
	    int s;

	        s = SUM(98, 1024);
		    printf("%d\n", s);
		        return (0);
}

