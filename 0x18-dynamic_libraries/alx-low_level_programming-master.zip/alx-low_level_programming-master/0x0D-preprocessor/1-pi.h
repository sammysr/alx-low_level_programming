#ifndef _1_PI_H
#define _1_PI_H

#define PI 3.14159265359

#endif

