#ifndef _4_SUM_H
#define _4_SUM_H

#define SUM(X, Y) ((X) + (Y))

#endif

