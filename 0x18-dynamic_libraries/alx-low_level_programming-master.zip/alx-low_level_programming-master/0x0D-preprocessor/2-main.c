#include "main.h"
#include <stdio.h>
#include <stdlib.h>

/**
 * main - Entery point
 *
 * Return: 0 (SUCESS)
 */
int main(void)
{
	printf("%s\n", __FILE__);
	return (EXIT_SUCCESS);
}

