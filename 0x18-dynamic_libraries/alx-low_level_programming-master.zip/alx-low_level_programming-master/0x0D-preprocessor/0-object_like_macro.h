#ifndef _0_OBJECT_LIKE_MACRO_H
#define _0_OBJECT_LIKE_MACRO_H

#define SIZE 1024

#endif

