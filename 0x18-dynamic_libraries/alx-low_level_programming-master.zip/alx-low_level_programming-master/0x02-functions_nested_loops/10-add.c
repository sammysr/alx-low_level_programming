#include "main.h"
/**
 * add - adds two integers together
 * @a: value to be used for sum.
 * @b: second value to be use for sum.
 *
 * Return: int (Sum)
 */
int add(int a, int b)
{
	return (a + b);
}

